use clap::{Arg, Command};
mod quiz;
mod util;

use quiz::{practice_problems_random_order, read_problems_from_csv};

fn main() -> Result<(), std::io::Error> {

    let cmd = Command::new("application")
        .author("Me?").about("Input the file path")
        .arg(
            Arg::new("problem-csv")
                .long("problem-csv")
                .value_name("CSV_FILE")
                .help("Sets the source file for problems to practice").required(true)
                .help("Sets the source file for problems to practice")
        )
        .get_matches();


    let binding = cmd.get_one::<String>("problem-csv").expect("CSV file path required").clone();
    let file_path = binding.as_str();
    // "src/resources/problems.csv"
    let problems = read_problems_from_csv(file_path)?;
    let problems = problems
        .iter()
        .map(|(q, a)| (q.as_str(), a.as_str()))
        .collect::<Vec<_>>();
    practice_problems_random_order(&problems);
    Ok(())
}
