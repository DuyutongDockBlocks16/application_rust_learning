mod quiz;
mod util;

use quiz::{practice_problems_random_order, read_problems_from_csv};

fn main() -> Result<(), std::io::Error> {
    let problems = read_problems_from_csv("src/resources/problems2.csv")?;
    let problems = problems
        .iter()
        .map(|(q, a)| (q.as_str(), a.as_str()))
        .collect::<Vec<_>>();
    practice_problems_random_order(&problems);
    Ok(())
}
