#[derive(Default)]
pub struct Player {
    // Add fields as required
}