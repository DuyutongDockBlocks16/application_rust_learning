#[derive(Default)]
pub struct Wall {
    // Fields
}