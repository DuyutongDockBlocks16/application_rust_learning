#[derive(Default)]
pub struct Collectible {
    // Fields
}