use application::game;

fn main() {
    #[allow(unused)]
        let mut game = game::Game::new();
}
