#[derive(Default)]
pub struct Collectible {}